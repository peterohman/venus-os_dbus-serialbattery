.. _errors:

Error Handling
==============

.. automodule:: can.exceptions
    :members:
    :show-inheritance:
