Utilities
---------


.. autofunction:: can.detect_available_configs


